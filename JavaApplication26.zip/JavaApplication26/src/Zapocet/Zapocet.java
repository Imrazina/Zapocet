
package Zapocet;

import java.util.Scanner;

public class Zapocet {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
                int pocetPrvku;
                while(true){
                System.out.println("Zadej pocet prvku, cislo mezi 5 a 20");
                pocetPrvku = input.nextInt();
                    if(pocetPrvku > 5 && pocetPrvku<20){
                        break;
                  }
                    
                  System.out.println("Pocet prvku musi byt mezi 5 a 20");   
                  }

        Pole pole = new Pole(pocetPrvku);
        pole.ZadejCisla();
        System.out.println(pole.toString());
        pole.IndexMinKladny();
        pole.IndexMaxZaporny();
    
    
    }
}

