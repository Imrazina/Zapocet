
package Zapocet;

import java.util.Arrays;
import java.util.Scanner;

public class Pole {
    private int [] array;
    public Pole(int pocetPrvku){

    array = new int[pocetPrvku];
    }
    
    
    
    
    
   public void ZadejCisla(){

   System.out.println("Zadej cisla od -100 do 100\n" + "rozmer pole: " + array.length);
    Scanner input = new Scanner(System.in);
   
      for(int i =0; i<array.length; i++){
      int cislo;
      boolean isValid;
       
      do{
       cislo = input.nextInt();
       isValid = (cislo>=-100 && cislo<=100);
       if(isValid){
       array[i] = cislo;
           System.out.println("Dalsi cislo");
       
          
      } else{
          System.out.println("Spatne zadane cislo");
         
       }
      } while(!isValid);
      }

   }
    
    
    
  
    @Override
    
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Pole: (");
            for(int i =0; i<getPocet(); i++){
            sb.append(getPrvek(i));
            if(i!=getPocet() -1);{
            sb.append("; ");
            }
        }
        sb.append(")");
        return sb.toString();
    }
    
    
    public int IndexMinKladny(){
   int min = 100; 
    int index = -1;

    for (int i = 0; i < array.length; i++) {
        if (getPrvek(i) > 0 && getPrvek(i) < min) {
            min = getPrvek(i);
            index = i;
        }
    }

    if (index == -1) {
        System.out.println("V poli nejsou kladna cisla.");
    } else {
        System.out.println("Minimalne kladne cislo: "+ "Pole[" + index + "] :" + min);
    }

    return index;
}

    public int IndexMaxZaporny(){
    int max = -100; 
    int index = 1;

    for (int i = 0; i < array.length; i++) {
        if (getPrvek(i) < 0 && getPrvek(i) > max) {
            max = getPrvek(i);
            index = i;
        }
    }

    if (index == 1) {
        System.out.println("V poli nejsou zaporna cisla.");
    } else {
        System.out.println("Minimalne kladne cislo: " + "Pole[" + index + "] :" + max );
    }

    return index;
    
    }
    
    public int getPocet(){
    return array.length;
    }
    
   public int getPrvek(int index){
   return array[index];
    }
    
    
    public void setPrvek(int index, int hodnota){
    array[index] = hodnota;
  
    }

  
    
}
